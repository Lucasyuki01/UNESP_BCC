#include <system.h>
#include <stdio.h>

/*Ponteiros*/
PTR_DESC ponteiro_main, ponteiro_tic, ponteiro_tac;

/*Co-rotina tic mod*/
void far tic(){
     int i = 0;
     while(i < 100){
       printf("TIC");
       transfer(ponteiro_tic, ponteiro_tac); /* Manda o controle para tac */
       i++;
     }
     
     transfer(ponteiro_tic, ponteiro_main);/* Manda o controle para a main */
}

/*Co-rotina tac mod*/
void far tac(){
     while(1){
       printf("TAC");
      
       transfer(ponteiro_tac, ponteiro_tic); /* Manda o controle para tic */
     }
}

main(){
    /* Inicializacao dos ponteiros */
    ponteiro_main = cria_desc();
    ponteiro_tic = cria_desc();
    ponteiro_tac = cria_desc();
    
    /* Criacao dos processos*/
    newprocess(tic, ponteiro_tic);
    newprocess(tac, ponteiro_tac);
    
    /*Manda o controle da main para "tic" */
    transfer(ponteiro_main, ponteiro_tic);
    
	/* Mata o programa */
    printf("\nFim\n");
    system("pause");
}
