#include <system.h>
#include <stdio.h>

/* Ponteiros */
PTR_DESC ponteiro_main, ponteiro_a, ponteiro_b, ponteiro_escalonador;

/* Co-rotina A */
void far corotina_a(){
    while(1){
    printf("Corotina A\n"); /* Printa Co-rotina A */
  }
}

/* Co-rotina B */
void far corotina_b(){
    while(1){
    printf("Corotina B\n"); /* Printa Co-rotina B */
  }
}


void far escalador(){
  /* Variaveis de entrada */
  p_est->p_origem = ponteiro_escalonador; /*Origem = Escalador */  
  p_est->p_destino = ponteiro_a;  /* Destino = Corotina A */
  p_est->num_vetor = 8;      /* Timer = reg. 8 (quantum) */

    while(1){
    iotransfer(); /* Transfere de p_origem para p_destino */
    disable();    /* Desativa as interrupcoes para evitar possiveis problemas */
    if(p_est->p_destino == ponteiro_a){
      p_est->p_destino = ponteiro_b; /* Troca o destino para a Corotina B */
    }
    else{
      p_est->p_destino = ponteiro_a; /* Troca o destino para a Corotina A */
    }
    enable(); /* Habilita as interrupcoes novamente para usar o Timer */
  }
}

main(){
  /* Inicialização dos ponteiros */
  ponteiro_main = cria_desc();
  ponteiro_a = cria_desc();
  ponteiro_b = cria_desc();
  ponteiro_escalonador = cria_desc();

  /* Criação dos processos */
  newprocess(corotina_a, ponteiro_a);
  newprocess(corotina_b, ponteiro_b);
  newprocess(escalador, ponteiro_escalonador);

  /* Transfere o controle da main para o escalador */
  transfer(ponteiro_main, ponteiro_escalonador);

  printf("\nFim Programa\n");
  system("pause");
}
