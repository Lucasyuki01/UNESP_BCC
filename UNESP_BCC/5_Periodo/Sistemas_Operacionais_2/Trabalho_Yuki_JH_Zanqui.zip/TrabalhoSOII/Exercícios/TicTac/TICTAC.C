#include <system.h>
#include <stdio.h>

/*Ponteiros*/
PTR_DESC ponteiro_main, ponteiro_tic, ponteiro_tac;

/*Co-rotina tic */
void far tic(){
     while(1){
       printf("Tic -"); /* Printa tic */
       transfer(ponteiro_tic, ponteiro_tac); /* Manda o controle para tac */
     }
}

/* Co-rotina tac */
void far tac(){
     while(1){
       printf(" Tac\n"); /* Printa tac */
       transfer(ponteiro_tac, ponteiro_tic); /* Manda o controle para tic */
     }
}

main(){
    /* Inicilizao dos ponteiros */
    ponteiro_tic = cria_desc();
    ponteiro_tac = cria_desc();
    ponteiro_main = cria_desc();
    
    /* Criacao dos processos*/
    newprocess(tic, ponteiro_tic);
    newprocess(tac, ponteiro_tac);
    
    /* Inicializacao do primeiro tic */
    transfer(ponteiro_main, ponteiro_tic);
}
