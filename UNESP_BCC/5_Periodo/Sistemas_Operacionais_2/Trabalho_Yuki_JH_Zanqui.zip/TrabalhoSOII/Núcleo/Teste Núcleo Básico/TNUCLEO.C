/*teste para n�cleo b�sico*/

#include <nucleo.h>
#include <stdio.h>

void far processo1(){
	int i = 0;
	while(i < 10000){
		printf("1");
		i++;
 	}
	termina_processo();
}

void far processo2(){
	int i = 0;
	while(i < 10000){
		printf("2");
		i++;
	}
	termina_processo();
}

void far processo3(){
	int i = 0;

	while(i < 10000){
		printf("3");
		i++;
	}
	termina_processo();
}

main(){
	cria_processo(processo1, "proc1");
	cria_processo(processo2, "proc2");
	cria_processo(processo3, "proc3");
	dispara_sistema();
}
