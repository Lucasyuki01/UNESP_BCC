/*teste do mecanismo de sem�foro(produtor, consumidor)*/

#include <nucleo.h>
#include <stdio.h>

FILE *arquivo;

semaforo mutex;
semaforo vazio; 
semaforo cheio;

int proximoItem = 0, proximoConsome = 0;
char buffer [100];
int aux = 0;    

int far produzir_item(){
	aux += 2;
	return aux;   
}

void far inserir_item(int item){
	buffer[proximoItem] = item;
	fprintf(arquivo, "O produtor criou o item %d [%d]\n", item, proximoItem);
	proximoItem += 1;
	if(proximoItem == 100)
	proximoItem = 0;
}

void far remover_item(){
	int item = buffer[proximoConsome];
	fprintf(arquivo, "O consumidor consumiu o item %d [%d]\n", item, proximoConsome);
	proximoConsome += 1;
	if(proximoConsome == 100)
	proximoConsome = 0;
}

void far produtor(){
	int i = 100;
	int item;

	while(i--){
		item = produzir_item();
		P(&vazio);
		P(&mutex);
		inserir_item(item);
		V(&mutex);
		V(&cheio);
	}
	termina_processo();
}

void far consumidor(){
	int i = 100;

	while(i--){
		P(&cheio);
		P(&mutex);
		remover_item();
		V(&mutex);
		V(&vazio);
	}
	termina_processo();
}

main(){
	arquivo = fopen("T2NUCLEO.txt", "w");
	if(arquivo == NULL)
		return;
	inicia_semaforo(&mutex, 1);
	inicia_semaforo(&vazio, 100);
	inicia_semaforo(&cheio, 0);
	cria_processo(produtor, "produtor");
	cria_processo(consumidor, "consumidor");
	dispara_sistema();
	fclose(arquivo);
}
