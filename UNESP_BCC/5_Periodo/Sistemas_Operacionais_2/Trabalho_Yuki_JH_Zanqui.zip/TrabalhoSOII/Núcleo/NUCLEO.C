/*cria��o das estruturas b�sicas do n�cleo e implementa��o do mecanismo de sem�foros*/

#include <system.h>

typedef struct registros{ /* verifica regi�o critica do DOS*/
	unsigned bx1,es1;
}regis;

typedef union k{
	regis x;
	char far *y;
}APONTA_REG_CRIT;

APONTA_REG_CRIT  a;

typedef struct desc_p{ /*descritor de processo associado*/
    char nome[35];
    enum
    {
        ativo,
        bloq_P,
        terminado
    } estado;
    PTR_DESC contexto;
    struct desc_p *fila_sem;
    struct desc_p *prox_desc;
} DESCRITOR_PROC;

typedef DESCRITOR_PROC *PTR_DESC_PROC;

typedef struct{ /*cria��o do tipo sem�foro*/
    int s;
    PTR_DESC_PROC Q;
} semaforo;


PTR_DESC_PROC prim = NULL;
PTR_DESC d_esc;

void far volta_DOS(){ /*desinstala o escalonador e retorna o controle para o DOS*/
    disable();
    setvect(8, p_est->int_anterior);
    enable();
    exit(0);
}

void far cria_processo(void far (*end_proc)(), char nome_p[35]){ /*associa um descritor de processo ao c�digo do processo e coloca-o na fila dos prontos*/
    PTR_DESC_PROC aloca_processo = (PTR_DESC_PROC)malloc(sizeof(struct desc_p));
    strcpy(aloca_processo->nome, nome_p);
    aloca_processo->estado = ativo;
    aloca_processo->contexto = cria_desc();
    newprocess(end_proc, aloca_processo->contexto);
    aloca_processo->fila_sem = NULL;
    aloca_processo->prox_desc = NULL;
    if (prim == NULL){
        aloca_processo->prox_desc = aloca_processo;
        prim = aloca_processo;
    }
    else{
        PTR_DESC_PROC aux = prim;
        while (aux->prox_desc != prim){
            aux = aux->prox_desc;
        }
        aux->prox_desc = aloca_processo;
        aloca_processo->prox_desc = prim;
    }
}

void far termina_processo(){ /*marca o processo chamador como "terminado"*/
    disable();
    prim->estado = terminado;
    enable();
    while (1)
        ;
}


PTR_DESC_PROC Procura_prox_ativo(){ /*retorna o endere�o do descritor do pr�ximo processo ativo da fila dos prontos*/
    PTR_DESC_PROC prox_ativo = prim->prox_desc;
    while (prox_ativo != prim){
        if (prox_ativo->estado == ativo){
            return prox_ativo;
        }
        prox_ativo = prox_ativo->prox_desc;
    }
    return NULL;
}

void far escalador(){
	p_est->p_origem = d_esc;
	p_est->p_destino = prim->contexto;
	p_est->num_vetor = 8;
	/* inicia ponteiro para R.C. do DOS */
	_AH=0x34;
	_AL=0x00;
	geninterrupt(0x21);
	a.x.bx1=_BX;
	a.x.es1=_ES;
	while(1){
		iotransfer();
		disable();
	if (!*a.y){
	/* se a interrup��o do timer n�o ocorreu dentro do DOS, troca o processo*/
		if((prim=Procura_prox_ativo())==NULL)
	        volta_DOS();
		p_est->p_destino=prim->contexto;
	}
	/* caso contr�rio, conceda mais uma fatia ao mesmo processo */
	enable();
	}
}

void far dispara_sistema(){	/*transfere o controle do programa principal para o escalonador*/
	PTR_DESC desc_dispara;
    d_esc = cria_desc();
    desc_dispara = cria_desc();
    newprocess(escalador, d_esc);
    transfer(desc_dispara, d_esc);
}

void far inicia_semaforo(semaforo *sem,int n){ /*primitiva para inicia��o do sem�foro*/
    sem->s = n;
    sem->Q = NULL;
}

void far P(semaforo *sem){ /*primitiva da opera��o P (ou DOWN)*/
    disable();
    if (sem->s > 0){
        sem->s--;
    }
    else{
        PTR_DESC_PROC p_aux;
        prim->estado = bloq_P;
        if (sem->Q == NULL){
            sem->Q = prim;
        }
        else{
            PTR_DESC_PROC aux;
            aux = sem->Q;
            while (aux->fila_sem != NULL){
                aux = aux->fila_sem;
            }
            aux->fila_sem = prim;
        }
        prim->fila_sem = NULL;
        p_aux = prim;
        if ((prim = Procura_prox_ativo()) == NULL){
            volta_DOS();
        }
        transfer(p_aux->contexto, prim->contexto);
    }
    enable();
}

void far V(semaforo *sem){ /*primitiva da opera��o V (ou UP)*/
    disable();
    if (sem->Q == NULL){
        sem->s++;
    }
    else{
        PTR_DESC_PROC p_prox;
        p_prox = sem->Q;
        sem->Q = p_prox->fila_sem;
        p_prox->fila_sem = NULL;
        p_prox->estado = ativo;
    }
    enable();
}
